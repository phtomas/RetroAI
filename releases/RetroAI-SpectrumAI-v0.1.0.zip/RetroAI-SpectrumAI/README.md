# RetroAI — SpectrumAI

Plugin público de assistência técnica a **TK90X, TK95 e ZX Spectrum**: diagnóstico de placas, Z80, ULA, ROM, RAM, vídeo, teclado, esquemas, expansões e restauração. O foco é medir, testar e documentar, sem inventar conclusões.

> Nada é “funcionou” sem prova. Isole e meça antes de adivinhar.

## Instalar ou utilizar

**Diretório público:** após a aprovação e publicação pela OpenAI, procure **RetroAI — SpectrumAI** em **Plugins** do ChatGPT, selecione **Instalar** e mencione o plugin na conversa. A disponibilização direta não decorre automaticamente da publicação deste repositório.

**Pacote ZIP:** baixe `RetroAI-SpectrumAI-v0.1.0.zip` na pasta `releases/` deste repositório. Em contas/ambientes com permissão de upload de plugins, use a opção de envio de ZIP. O pacote também pode ser instalado a partir de um marketplace local/repositório compatível no Codex. A interface e as permissões disponíveis dependem do plano e do ambiente.

**Código-fonte:** `plugins/retroai-spectrumai/`. É uma distribuição portátil do núcleo técnico (skill), sem conexões privadas e sem o acervo pessoal do autor. O plugin instalado na conta do autor pode conter recursos adicionais não reproduzidos aqui.

## Comece por uma pergunta

> “Meu TK90X liga, mas só mostra a tela preta. Como verificar +5V, clock e RESET antes de trocar componentes?”

Informe, quando possível, **modelo, revisão da placa, sintoma, intervenções já realizadas e medições**. Nunca trabalhe em placa energizada sem treinamento e proteções adequadas.

## Para autores e leitores

Guia curto para inserção em livro: [`docs/Guia-de-uso-RetroAI.md`](docs/Guia-de-uso-RetroAI.md). Esse arquivo pode ser citado no livro como endereço permanente para informações de instalação atualizadas.

## Privacidade e referências

O pacote público **não inclui** credenciais, IDs de pastas privadas, manuais de terceiros, PDFs ou imagens cujo direito de redistribuição não tenha sido confirmado. Para documentos pessoais, cada usuário deve autorizar suas próprias conexões. O núcleo público foi reconstruído a partir das instruções técnicas do plugin do autor; não é uma exportação binária integral do plugin instalado.

Projeto: https://github.com/phtomas/RetroAI

Documentação do formato: https://developers.openai.com/plugins/build/plugins
